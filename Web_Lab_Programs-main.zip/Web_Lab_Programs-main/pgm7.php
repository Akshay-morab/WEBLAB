<!DOCTYPE HTML>
<html>
<head>
<meta http-eqiv="refresh" content="1"/>
</head>
<style>
p{
    color:white;
    font-size:90px;
    position:absolute;
    top:50%;
    left:50%;
    transform:translate(-50%,-50%);
}
body{ background-color:black;}
</style>
    <p> <?php echo date("h:i:s A");?> </p>
</html>